var searchData=
[
  ['app_5fbuffer_5fsize_142',['APP_BUFFER_SIZE',['../main_8c.html#a7ea0c6405141cdcf25345cbf3d74e0eb',1,'main.c']]]
];
