var searchData=
[
  ['scl_124',['scl',['../structgnssrtk3__cfg__t.html#ac5909ef3bd73ac3d682f91bb79baa56f',1,'gnssrtk3_cfg_t']]],
  ['sda_125',['sda',['../structgnssrtk3__cfg__t.html#adc3dc5e0cc6fe9e112104a64a9bd8c61',1,'gnssrtk3_cfg_t']]],
  ['stop_5fbit_126',['stop_bit',['../structgnssrtk3__cfg__t.html#ac4c14aa578a0012f2140c35dba362d6c',1,'gnssrtk3_cfg_t']]]
];
