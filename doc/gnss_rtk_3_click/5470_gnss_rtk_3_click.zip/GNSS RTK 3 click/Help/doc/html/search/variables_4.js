var searchData=
[
  ['parity_5fbit_119',['parity_bit',['../structgnssrtk3__cfg__t.html#ad76f6283ed88037a8e5abe4f751d6797',1,'gnssrtk3_cfg_t']]],
  ['pps_120',['pps',['../structgnssrtk3__s.html#a5faa872c6e8cb1c659879fcda4bba32a',1,'gnssrtk3_s::pps()'],['../structgnssrtk3__cfg__t.html#a3ee5196e420a5fa301c6bdada8e82d45',1,'gnssrtk3_cfg_t::pps()']]]
];
