var searchData=
[
  ['process_5fbuffer_5fsize_143',['PROCESS_BUFFER_SIZE',['../main_8c.html#aec4c8b68ebf6f92a5acd1f0778a40999',1,'main.c']]]
];
