var searchData=
[
  ['app_5fbuffer_5fsize_0',['APP_BUFFER_SIZE',['../main_8c.html#a7ea0c6405141cdcf25345cbf3d74e0eb',1,'main.c']]],
  ['application_5finit_1',['application_init',['../main_8c.html#a0e95431f48ee71c1040217b94766ffcf',1,'main.c']]],
  ['application_5ftask_2',['application_task',['../main_8c.html#a362899c9f270bb296179185fd96b878e',1,'main.c']]]
];
