var searchData=
[
  ['tx_5fpin_127',['tx_pin',['../structgnssrtk3__cfg__t.html#aa7a940d4461591c0d821c67e192b90c9',1,'gnssrtk3_cfg_t']]]
];
